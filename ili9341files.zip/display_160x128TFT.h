// Display Routines
//
// (c) Cumbria Designs
//
// Display Header File
//

// Control
#define DISP_REFRESH     1000                   // Number of ISR passes between refresh

// S-Meter Scale
#define MTR_START       60                      // Start point for meter scale and graph
#define DB_SCALE        12
#define RXSCALE         14                       // Page number for scale
#define BAR             16                       // Page number for bar graph
#define S_MTR_UPD       200                     // Number of ISR passes between meter updates
#define RX_GRAPH        16                       // Page number for graph
// Tx-Meter Scale
#define Tpoint          10                      // Number of pixels per graduation
#define TXFSD           (10*Tpoint)             // Full scale in pixels
#define TXSCALE         6                       // Page number for scale
#define TXAXIS          7                       // Page number for graph
// Drawing Elements
#define SMTR_START      2                       // Column position for meter start
#define TXMTR_START     14                      // Column position for meter start
// Mode Values
#define    USB              1               // USB
#define    LSB              2               // LSB
#define    CW               3               // CW
#define    CWR              4               // CW Reverse sideband
// AF Processing Flags
#define    DN_ON            1               // Denoise on
#define    DN_OFF          0xfffe           // Denoise off
#define    AN_ON            2               // Autonotch on
#define    AN_OFF          0xfffd           // Autonotch off
#define    NO_PROC          0               // No AF Processing
#define    AD_ON            3               // Autonotch and denoise on
// Function Values
#define    FUNC_BAND        1               // Band change function
#define    FUNC_MODE        2               // Mode change function
#define    FUNC_FILTER      3               // Filter change function
#define    FUNC_AGC         4               // AGC functions
// Setting Values to drive sub menu etc
#define    SET_CAL          1               // VFO calibration
#define    SET_RX_BAL       2               // Rx I/Q balance
#define    SET_TX_BAL       3               // Tx I/Q balance
#define    SET_MIC_GAIN     4               // Microphone gain
#define    SET_MIC_PRE      5               // Microphone pre-emphasis
#define    SET_IQ_SWAP      6               // Tx/Rx I/Q Harware Swap
// Filter Values
#define    SSB_1            9               // Voice Wide
#define    SSB_2            8               // Voice
#define    SSB_3            7               // Voice
#define    SSB_4            6               // Voice
#define    SSB_5            5               // Voice narrow
#define    CW_1             4               // Voice narrow
#define    CW_2             3               // CW Wide
#define    CW_3             2               // CW
#define    CW_4             1               // CW narrow
// Mic Gain
#define    MIC_FIXED_GAIN   20              // +20dB fixed gain in CODEC

// Linear to log table 1dB steps for S-Meter rangel S0..S9+36
// remainder of range to +66dB to be used when external PGAs added

const int linear_dB[73]={0x0001,0x0001,        0x0001,        0x0001,        0x0001,        0x0001,
                        0x0002,        0x0002,        0x0002,        0x0002,        0x0003,        0x0003,
                        0x0004,        0x0004,        0x0005,        0x0005,        0x0006,        0x0007,
                        0x0008,        0x0009,        0x000A,        0x000B,        0x000D,        0x000E,
                        0x0010,        0x0012,        0x0014,        0x0017,        0x001A,        0x001D,
                        0x0020,        0x0024,        0x0029,        0x002E,        0x0033,        0x003A,
                        0x0041,        0x0049,        0x0052,        0x005C,        0x0067,        0x0074,
                        0x0082,        0x0092,        0x00A4,        0x00B8,        0x00CE,        0x00E7,
                        0x0104,        0x0124,        0x0147,        0x016F,        0x019C,        0x01CE,
                        0x0207,        0x028D,        0x0337,        0x040C,        0x0518,        0x066A,
                        0x0813,        0x0A2A,        0x0CCC,        0x101D,        0x1449,        0x1989,
                        0x2026,        0x2879,        0x32F4,        0x4026,        0x50C2,        0x65AB,
                        0x7FFF,
                        };