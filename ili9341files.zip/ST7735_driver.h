// ST7735 TFT Driver
//
// (c)Cumbria Designs
//
// Header file
//
// ST7735 TFT Definitions

extern void Display_Freq(unsigned long freq);
extern void init_disp();
extern void start_up_msg();
void  write_disp_SPI16(unsigned disp_word);
void write_disp_SPI8(unsigned char disp_byte);
void disp_com(unsigned char disp_byte);
void disp_byte(unsigned disp_char );
void disp_word(int char_data);
extern void disp_colour(unsigned int foregnd, unsigned int back);
void disp_addr_win();
void disp_addr(unsigned char page, unsigned char col);
void disp_font(unsigned char font_type, unsigned char chr_space);
extern void disp_chr(unsigned char chr);
void disp_orientation(int degrees);
void disp_str(register const char *str);
void disp_gra(unsigned char byte);
void disp_write();
void disp_clr();
void display_MHz();
extern void display_save();
extern void display_rate(int new_step) ;
extern void display_vfo();
extern void display_ab(int ab);
extern void display_a_b();
extern void display_rx();
extern void display_tx();
extern void display_meterscale();
extern void rx_meter_scale();
extern void rx_meter(unsigned int agc_dB);
extern void display_mode(unsigned int mode);

// ST7735 I/O Port
// I/O Port
#define DISP_SPI_PORT   TRISB       // SPI on Port B
#define DISP_SPI_DIR    0xff00      // Port B pin direction for "AND-ing" in
// SPI Pin Names

#define DISP_CS         LATB1_bit                         // Chip Select
#define DISP_DC         LATB2_bit                         // Data/Command
#define DISP_RES        LATB0_bit                         // Reset (Active Low)
#define DISP_SDIN       LATB3_bit                         // Data Out
#define DISP_SCLK       LATB4_bit                         // Clock Out

// ST7735 Commands

#define SWRESET     0x01        // software reset
#define SLPOUT      0x11        // sleep out
#define DISPOFF     0x28        // display off
#define DISPON      0x29        // display on
#define CASET       0x2A        // column address set
#define RASET       0x2B        // row address set
#define RAMWR       0x2C        // RAM write
#define MADCTL      0x36        // Axis control
#define COLMOD      0x3A        // Colour mode
// Basic Colours
#define BLACK       0x0000
#define BLUE        0x001F
#define RED         0xF800
#define GREEN       0x0400
#define LIME        0x07E0
#define CYAN        0x07FF
#define MAGENTA     0xF81F
#define YELLOW      0xFFE0
#define WHITE       0xFFFF
