/*
 * Project name:
     Lcd_Test (Demonstration of the LCD library routines)
 * Copyright:
     (c) Mark Flavin N5MF, 2017.
 * Revision History:
     20170210:
       - initial release (FN);
 * Description:
     DDS SI5351A
 * Test configuration:
     MCU:             PIC18F25K22
                      http://ww1.microchip.com/downloads/en/DeviceDoc/41412D.pdf
     dev.board:       easypic7lcd
                      http://www.mikroe.com/eng/products/view/757/easypic-v7-development-system/
     Oscillator:      Internal Osc 16.0000 MHz, 20.0000 MHz Crystal
     Ext. Modules:    Character Lcd 2x16
                      http://www.mikroe.com/eng/products/view/277/various-components/
     SW:              mikroC PRO for PIC
                      http://www.mikroe.com/eng/products/view/7/mikroc-pro-for-pic/
 * NOTES:


        qUADRTURE Version
*/
#include <built_in.h>
#include "ST7735_driver.h"
#include "MyProject.h"
#include "si5351a.h"

// ----------------------Text Strings ---------------------------------

char vfoa[6] = "VFO A";
char vfob[6] = "VFO B";
char split[6] = "Split";
char rit[6] = " RIT ";
char tmit[3] = "Tx" ;
char rcv[3] = "Rx" ;
char freq_display[11] = "          ";
char rit_display[6] = "     "  ;
char data;

// ---------------------------Counter Stuff  --------------------------------

unsigned long int freq_counta;
unsigned long int freq_countb;
unsigned long int freq_holder;
unsigned long int freq_holderql;
unsigned long int band_offset;
unsigned long int cal_offset;
unsigned long rit_count = 0;
unsigned char w0=0x00;              // 0 deg offset
unsigned char w1=0x44;              // 90 deg offset
unsigned short eeprom_in;
unsigned short eeprom_out ;

int ptr;
int counter;
int  i;
bit split_onoff;
bit rit_onoff;
bit rev_onoff ;
bit RIT_On;
bit VFO_AB;    // 0 = A   1 = B
bit old_vfo;
bit fq_upd;
bit tx_on;
bit cal;
bit freq_change;
bit band_updn;
int initialize;
int VFO_Temp;
unsigned char state;
signed int count;
long int step = 10;
int USB=1;
int LSB=2;
int CWN=3;
int CWR=4;
int Mode_set = 1;
unsigned agc_temp;
//unsigned int temp_step;
unsigned int Addr = 0x00;
short int band_set;
unsigned int last_band = 0x00;
//unsigned int last_step = 0x02;
//unsigned int bfo_offset = 0x04;
//unsigned int band_dir = 0x06;
//unsigned int init = 0x00;

struct band_info {
    unsigned long int Freq_a;
    unsigned long int Freq_b;
    unsigned int EEPROM_Addr;
    } forty = {7000000, 7000000, 0x10}, thirty = { 10100000, 101000000, 0x20}, twenty = {14000000, 14000000, 0x30},
      seventeen = {18068000, 18068000, 0x40},  fifteen = {21005000, 21005000, 0x050}; //, ten = { 19808000, 19808000, 0x90} ;


// -----------Rotary encoder interrupt-------------------------------------

void interrupt(void){

if(INTCON.RBIF==1)
{
static unsigned char prevState=0xFF;
INTCON.RBIE = 0;
state = PORTB.RB6 | PORTB.RB7<<1;
if(prevState != 0xFF)//If this is not the first time we enter the interrupt, process the gray codes
{
if(prevState == 0b00 && state == 0b01 //Turn counterclockwise
|| prevState == 0b01 && state == 0b11
|| prevState == 0b11 && state == 0b10
|| prevState == 0b10 && state == 0b00)
{
 if (rit_onoff == 1)
     rit_count = rit_count + 10;
     
 if (VFO_AB == 0  )
    freq_counta = freq_counta-step; //count dow
else
    freq_countb = freq_countb-step;
}

else

if(prevState == 0b00 && state == 0b10 //Turn clockwise
|| prevState == 0b10 && state == 0b11
|| prevState == 0b11 && state == 0b01
|| prevState == 0b01 && state == 0b00)
{
if (rit_onoff == 1)
     rit_count = rit_count - 10;

if (VFO_AB == 0  )
   freq_counta = freq_counta+step; //count up
else
   freq_countb = freq_countb+step;
}
}
prevState = state; //Save previous port b state.
INTCON.RBIE = 1;
INTCON.RBIF=0; //Clear port B interrupts flag
fq_upd = 1;
}

}

void main()
 {
  ANSELB = 0;             // Configure PORTB pins
  ANSELC = 0;             // Configure PORTC pins
  //ANSELA = 0;             // Configure PORTA Pins
  ANSELA  = 0x04;
  //Setup Ports

  TRISA = 0b11111111;               // Set PORTA as input
  TRISB = 0b11000000;               // Set RB6-7 as input for encoder input change to 0b11110000 for 2 encoders
  TRISC = 0b11100111;               // Set PORTC as input
  TRISB6_bit  =1  ;
  TRISB7_bit  =1 ;
  

  //OSCCON = 0xFA;      //set int osc to 16Mhz
  PORTC = 0;
  LATC = 0x00;
  IOCB = 0xC0; //0x80;
  INTCON.GIE =1;
  INTCON.RBIE = 1;
  INTCON.RBIF = 0;
  T0CON	 = 0x87;
  TMR0H	 = 0x0B;
  TMR0L	 = 0xDC;


  INTCON.TMR0IF = 0;
  INTCON.GIE =1;
  

  
  //------------------- Initialize Lcd -----------------------
  
   init_disp();
   start_up_msg();
   ADC_Init();
  
  //--------------Initialize EEPROM on first startup -----------------
  
  eeprom_in = EEPROM_Read(0x10);
  if (eeprom_in != 0)
     {

     band_set = EEPROM_Read(last_band);

     }
  else
    {
    //Write_EEPROM(eighty.EEPROM_Addr, 6000000);
    //Write_EEPROM(eighty.EEPROM_Addr + 4, 6000000);
    //Write_EEPROM(eighty.EEPROM_Addr + 8, eighty.Freq_a);

    Write_EEPROM(forty.EEPROM_Addr, forty.Freq_a);
    Write_EEPROM(forty.EEPROM_Addr + 4, forty.Freq_b);
    //Write_EEPROM(forty.EEPROM_Addr + 8, forty.Freq_a);

    Write_EEPROM(thirty.EEPROM_Addr, thirty.Freq_a);
    Write_EEPROM(thirty.EEPROM_Addr + 4, thirty.Freq_b);
    //Write_EEPROM(thirty.EEPROM_Addr + 8, thirty.Freq_a);

    Write_EEPROM(twenty.EEPROM_Addr, twenty.Freq_a);
    Write_EEPROM(twenty.EEPROM_Addr + 4, twenty.Freq_b);
    //Write_EEPROM(twenty.EEPROM_Addr + 8, twenty.Freq_a);

    Write_EEPROM(seventeen.EEPROM_Addr, seventeen.Freq_a);
    Write_EEPROM(seventeen.EEPROM_Addr + 4, seventeen.Freq_b);
    //Write_EEPROM(seventeen.EEPROM_Addr + 8, seventeen.Freq_a);

    Write_EEPROM(fifteen.EEPROM_Addr,fifteen.Freq_a);
    Write_EEPROM(fifteen.EEPROM_Addr + 4, fifteen.Freq_b);
    // Write_EEPROM(fifteen.EEPROM_Addr + 8, fifteen.Freq_a);

    //Write_EEPROM(twelve.EEPROM_Addr, twelve.Freq_a);
    //Write_EEPROM(twelve.EEPROM_Addr + 4, twelve.Freq_b);
    //Write_EEPROM(twelve.EEPROM_Addr + 8, twelve.Freq_a);

    //Write_EEPROM(ten.EEPROM_Addr, ten.Freq_a);
    //Write_EEPROM(ten.EEPROM_Addr + 4, ten.Freq_b);
    //Write_EEPROM(ten.EEPROM_Addr + 8, ten.Freq_a);

    EEPROM_Write(last_band,0);
    Delay_ms(5);
    band_set = EEPROM_Read(last_band);
    //EEPROM_Write(band_dir,1);
    //EEPROM_Write(last_step, step);
    //EEPROM_Write(last_step +1, step>>8);
    //EEPROM_Write(init,1);
    }


 // -------------------------get last band  ------------------------------

/*
    if (band_set == 0)
        {
         freq_counta = Read_EEPROM(eighty.EEPROM_Addr);
         freq_countb = Read_EEPROM(eighty.EEPROM_Addr + 4);
         //band_offset = Read_EEPROM(eighty.EEPROM_Addr + 8);
         }
     */
    if (band_set == 0)
        {
         freq_counta = Read_EEPROM(forty.EEPROM_Addr);
         freq_countb = Read_EEPROM(forty.EEPROM_Addr + 4);
        // band_offset = Read_EEPROM(forty.EEPROM_Addr + 8);
         }
    else
    if (band_set == 1)
        {
         freq_counta = Read_EEPROM(thirty.EEPROM_Addr);
         freq_countb = Read_EEPROM(thirty.EEPROM_Addr + 4);
         //band_offset = Read_EEPROM(thirty.EEPROM_Addr + 8);
         }
     else
     if (band_set == 2)
        {
         freq_counta = Read_EEPROM(twenty.EEPROM_Addr);
         freq_countb = Read_EEPROM(twenty.EEPROM_Addr + 4);
         //band_offset = Read_EEPROM(twenty.EEPROM_Addr + 8);
         }
     else
     if (band_set == 3)
        {
         freq_counta = Read_EEPROM(seventeen.EEPROM_Addr);
         freq_countb = Read_EEPROM(seventeen.EEPROM_Addr + 4);
         // band_offset = Read_EEPROM(seventeen.EEPROM_Addr + 8);
         }
     else
     if (band_set == 4)
        {
         freq_counta = Read_EEPROM(fifteen.EEPROM_Addr);
         freq_countb = Read_EEPROM(fifteen.EEPROM_Addr + 4);
         // band_offset = Read_EEPROM(fifteen.EEPROM_Addr + 8);
         }
     /*
     else
     if (band_set == 3)
        {
         freq_counta = Read_EEPROM(twelve.EEPROM_Addr);
         freq_countb = Read_EEPROM(twelve.EEPROM_Addr + 4);
         //band_offset = Read_EEPROM(twelve.EEPROM_Addr + 8);
         }

     if (band_set == 4)
        {
         freq_counta = Read_EEPROM(ten.EEPROM_Addr);
         freq_countb = Read_EEPROM(ten.EEPROM_Addr + 4);
         //band_offset = Read_EEPROM(ten.EEPROM_Addr + 8);
         }
      */

  //--------------------get last step----------------------

  //Lo(step) = EEPROM_Read(last_step);
  //Hi(step) = EEPROM_Read(last_step+1);

  //--------------------------Set starting Step ---------------------

     //if (step == 10)
     //Lcd_Out(2,12," 10hz");
  /*
  else
     if (step == 100)
         //Lcd_Out(2,12,"100hz");

  else
     if (step == 1000)
         //Lcd_Out(2,12,"1 Khz");
  */
  //-------------initialize variables-------------
  //tx_on = 0;
  step = 10;
  VFO_AB = 0 ;
  rit_onoff = 0;
  split_onoff = 0;

  if (VFO_AB == 0)
     {
     freq_holder = freq_counta ;
     }
  else
     {
      freq_holder = freq_countb;
      }
 freq_holder = freq_counta ;
 display_vfo();
 display_ab(VFO_AB);
 display_mode(Mode_set);
 display_rate(step);
 display_rx();
 rx_meter_scale();
 display_meterscale();
 si5351aSetFrequency(freq_holder, 1);
 Display_Freq(freq_holder);
 display_MHz();

  // --------------------Start Program  -------------------------------

  while (1) {
         agc_temp = ADC_Read(2);
         rx_meter(agc_temp);
        //-----------------A=B ----------------------

        if(PORTA.RA0 == 0)
          {
           Delay_ms(250);
           if (VFO_AB == 1)
             {
             freq_counta = freq_countb;
          }
        else
          {
             freq_countb = freq_counta;
          }

          fq_upd = 1 ;
          display_a_b();
        }

       // ---------------Switch VFOs-----------------
       
       if (PORTA.RA1 == 0)
          {
           Delay_ms(250);
           if (VFO_AB == 0)
             {
              VFO_AB = 1 ;
              display_ab(VFO_AB);
              freq_holder = freq_countb;
              fq_upd = 1;
              //EEPROM_Write(last_vfo, 1) ;
              Delay_ms(1);
             }
           else
             {
              VFO_AB = 0;
              display_ab(VFO_AB);
              freq_holder = freq_counta;
              fq_upd = 1;
              //EEPROM_Write (last_vfo, 0);
              Delay_ms(1);
             }

        }


        //---------------------------Band Change Up------------------------------------

       if (PORTC.RC6 == 0)
        {
          Delay_ms(250);
            /*
            if (band_set == 0 )
                  {
                   Write_EEPROM(eighty.EEPROM_Addr, freq_counta);
                   Write_EEPROM(eighty.EEPROM_Addr + 4, freq_countb);
                   band_set = 1;
                   freq_counta = Read_EEPROM(forty.EEPROM_Addr);
                   freq_countb = Read_EEPROM(forty.EEPROM_Addr + 4);
                   band_offset = Read_EEPROM(forty.EEPROM_Addr + 8);
                   }
            else
            */
               if (band_set == 0 )
                  {
                   Write_EEPROM(forty.EEPROM_Addr, freq_counta);
                   Write_EEPROM(forty.EEPROM_Addr + 4, freq_countb);
                   band_set=1;
                   freq_counta = Read_EEPROM(thirty.EEPROM_Addr);
                   freq_countb = Read_EEPROM(thirty.EEPROM_Addr + 4);
                   //band_offset = Read_EEPROM(thirty.EEPROM_Addr + 8);
                  }

           else
               if (band_set  == 1)
                  {
                   Write_EEPROM(thirty.EEPROM_Addr, freq_counta);
                   Write_EEPROM(thirty.EEPROM_Addr + 4, freq_countb);
                   band_set=2;
                   freq_counta = Read_EEPROM(twenty.EEPROM_Addr);
                   freq_countb = Read_EEPROM(twenty.EEPROM_Addr + 4);
                   //band_offset = Read_EEPROM(twenty.EEPROM_Addr + 8);
                   }
           else
              if (band_set == 2)
                   {
                   Write_EEPROM(twenty.EEPROM_Addr, freq_counta);
                   Write_EEPROM(twenty.EEPROM_Addr + 4, freq_countb);
                   band_set=3;
                   freq_counta = Read_EEPROM(seventeen.EEPROM_Addr);
                   freq_countb = Read_EEPROM(seventeen.EEPROM_Addr + 4);
                   //band_offset = Read_EEPROM(seventeen.EEPROM_Addr + 8);
                   }
           else
              if (band_set == 3)
                  {
                   Write_EEPROM(seventeen.EEPROM_Addr, freq_counta);
                   Write_EEPROM(seventeen.EEPROM_Addr + 4, freq_countb);
                   band_set=4;
                   freq_counta = Read_EEPROM(fifteen.EEPROM_Addr);
                   freq_countb = Read_EEPROM(fifteen.EEPROM_Addr + 4);
                   //band_offset = Read_EEPROM(fifteen.EEPROM_Addr + 8);
                   }
          /*else
              if (band_set == 4)
                  {
                   Write_EEPROM(fifteen.EEPROM_Addr, freq_counta);
                   Write_EEPROM(fifteen.EEPROM_Addr + 4, freq_countb);
                   band_set++;
                   freq_counta = Read_EEPROM(twelve.EEPROM_Addr);
                   freq_countb = Read_EEPROM(twelve.EEPROM_Addr + 4);
                   //band_offset = Read_EEPROM(twelve.EEPROM_Addr + 8);
                   }

           else
              if (band_set == 3)
                  {
                   Write_EEPROM(twelve.EEPROM_Addr, freq_counta);
                   Write_EEPROM(twelve.EEPROM_Addr + 4, freq_countb);
                   band_set =4;
                   freq_counta = Read_EEPROM(ten.EEPROM_Addr);
                   freq_countb = Read_EEPROM(ten.EEPROM_Addr + 4);
                   //band_offset = Read_EEPROM(ten.EEPROM_Addr + 8);
                   }
          */
          split_onoff = 0;
          si5351aSetFrequency(freq_holder, 1);
          fq_upd = 1;
          EEPROM_Write(last_band, band_set);
        }

        //-------------------------Band Change    DOWN------------------------------

        if (PORTC.RC7 == 0)
         {
          Delay_ms(200);
          /*
               if (band_set == 7 )
                  {
                   Write_EEPROM(ten.EEPROM_Addr, freq_counta);
                   Write_EEPROM(eighty.EEPROM_Addr + 4, freq_countb);
                   band_set = 6;
                   freq_counta = Read_EEPROM(twelve.EEPROM_Addr);
                   freq_countb = Read_EEPROM(twelve.EEPROM_Addr + 4);
                   band_offset = Read_EEPROM(twelve.EEPROM_Addr + 8);
                   }
            else

               if (band_set == 5)
                  {
                   Write_EEPROM(twelve.EEPROM_Addr, freq_counta);
                   Write_EEPROM(twelve.EEPROM_Addr + 4, freq_countb);
                   band_set--;
                   freq_counta = Read_EEPROM(fifteen.EEPROM_Addr);
                   freq_countb = Read_EEPROM(fifteen.EEPROM_Addr + 4);
                   //band_offset = Read_EEPROM(fifteen.EEPROM_Addr + 8);
                     }
            else   */
               if (band_set  == 4)
                  {
                   Write_EEPROM(fifteen.EEPROM_Addr, freq_counta);
                   Write_EEPROM(fifteen.EEPROM_Addr + 4, freq_countb);
                   band_set=3;
                   freq_counta = Read_EEPROM(seventeen.EEPROM_Addr);
                   freq_countb = Read_EEPROM(seventeen.EEPROM_Addr + 4);
                   //band_offset = Read_EEPROM(seventeen.EEPROM_Addr + 8);
                   }
            else
               if (band_set == 3)
                   {
                   Write_EEPROM(seventeen.EEPROM_Addr, freq_counta);
                   Write_EEPROM(seventeen.EEPROM_Addr + 4, freq_countb);
                   band_set=2;
                   freq_counta = Read_EEPROM(twenty.EEPROM_Addr);
                   freq_countb = Read_EEPROM(twenty.EEPROM_Addr + 4);
                   //band_offset = Read_EEPROM(twenty.EEPROM_Addr + 8);
                   }

            else
               if (band_set == 2)
                  {
                   Write_EEPROM(twenty.EEPROM_Addr, freq_counta);
                   Write_EEPROM(twenty.EEPROM_Addr + 4, freq_countb);
                   band_set=1;
                   freq_counta = Read_EEPROM(thirty.EEPROM_Addr);
                   freq_countb = Read_EEPROM(thirty.EEPROM_Addr + 4);
                   //band_offset = Read_EEPROM(thirty.EEPROM_Addr + 8);
                   }
            else
               if (band_set == 1)
                  {
                   Write_EEPROM(thirty.EEPROM_Addr, freq_counta);
                   Write_EEPROM(thirty.EEPROM_Addr + 4, freq_countb);
                   band_set=0;
                   freq_counta = Read_EEPROM(forty.EEPROM_Addr);
                   freq_countb = Read_EEPROM(forty.EEPROM_Addr + 4);
                   //band_offset = Read_EEPROM(forty.EEPROM_Addr + 8);
                   }
          /*  else
               if (band_set == 1)
                  {
                   Write_EEPROM(forty.EEPROM_Addr, freq_counta);
                   Write_EEPROM(forty.EEPROM_Addr + 4, freq_countb);
                   band_set = 0;
                   freq_counta = Read_EEPROM(eighty.EEPROM_Addr);
                   freq_countb = Read_EEPROM(eighty.EEPROM_Addr + 4);
                   band_offset = Read_EEPROM(eighty.EEPROM_Addr + 8);
                   }
           */
          split_onoff = 0;
          si5351aSetFrequency(freq_holder, 1);
          fq_upd = 1;
          EEPROM_Write(last_band, band_set);

        }

       //---------------Split - RIT  ------------------------
       /*
       if  (PORTA.RA4 == 0) Change
         {
           Delay_ms(500);
         if (PORTA.RA2 == 0)
           {
           rit_onoff = 1;
           rit_count = 0;
           freq_countb = freq_counta;
           VFO_AB = 1;
           fq_upd = 1;
           display_RIT(rit_count);
           //Lcd_Out(1,12,rit);
           }
         else
           {
           if(!split_onoff && !rit_onoff)
           {
            split_onoff = 1;
            //Lcd_Out(1,12,split);
           }
         else
           {
            split_onoff = 0;
            rit_onoff = 0;
            VFO_AB = 0 ;
            fq_upd = 1;
            //Lcd_Out(1,12,vfoa);
            //Lcd_Out(2,6,"     ");
           }
           }
          Delay_ms(500);
         }
          */



        //-----------------change step  -----------------------------
        
        if  (PORTA.RA5 == 0)
        {   Delay_ms(500);
            if  (PORTA.RA5 == 0)
               {
                step = 10;
                display_rate(step);
               }
            else
             {
              if (step == 10 )
                  {
                   step = 100;
                   display_rate(step);
                   }

            else

              if (step == 100)
                  {
                   step = 1000 ;
                   //Lcd_Out(2,12,"1 Khz");
                   }

            else

              if (step == 100)
                  {
                   step = 10;
                   display_rate(step);
                   }
             }
          //EEPROM_Write(last_step, step);
          //EEPROM_Write(last_step +1, step>>8);
          Delay_ms(100);
        }
        
        
        // --------------------Calibrate Routine ----------------------------------
        /*
        if (PORTA.RA6 == 0)
            {
            Delay_ms(200);
            cal = 1;
            temp_step = step;
            step = 10;
            freq_holderql = freq_counta;

         if (band_set == 0)
               {
               freq_counta = Read_EEPROM(eighty.EEPROM_Addr + 8);
               }
         else
            if (band_set == 1)
               {
               freq_counta = Read_EEPROM(forty.EEPROM_Addr + 8);
               }
         else
            if (band_set == 2)
               {
               freq_counta = Read_EEPROM(thirty.EEPROM_Addr + 8);
               }
          else
            if (band_set == 3)
               {
               freq_counta = Read_EEPROM(twenty.EEPROM_Addr + 8);
               }
          else
            if (band_set == 4)
               {
               freq_counta = Read_EEPROM(seventeen.EEPROM_Addr + 8);
               }
          else
            if (band_set == 5)
               {
               freq_counta = Read_EEPROM(fifteen.EEPROM_Addr + 8);
               }

          else
            if (band_set == 6)
               {
               freq_counta = Read_EEPROM(twelve.EEPROM_Addr + 8);
               }
          else
            if (band_set == 7)
               {
               freq_counta = Read_EEPROM(ten.EEPROM_Addr + 8);
               }

            //Lcd_Out(2,9,"cal");

            while (cal == 1)
            {
              if (fq_upd)
                 {
                  band_offset = freq_counta ;
                  Display_Freq(freq_holder,1);
                  fq_upd = 0;
                 }

              if (PORTA.RA6 == 0)
                 {
                  Delay_ms(200);

                  if (band_set == 0)
                      Write_EEPROM(eighty.EEPROM_Addr + 8, band_offset);
              else
                  if (band_set == 1)
                      Write_EEPROM(forty.EEPROM_Addr + 8, band_offset);
              else
                  if (band_set == 2)
                      Write_EEPROM(thirty.EEPROM_Addr + 8, band_offset);
              else
                  if (band_set == 3)
                      Write_EEPROM(twenty.EEPROM_Addr + 8, band_offset);
              else
                  if (band_set == 4)
                      Write_EEPROM(seventeen.EEPROM_Addr + 8, band_offset);
              else
                  if (band_set == 5)
                      Write_EEPROM(fifteen.EEPROM_Addr + 8, band_offset);
              else
                  if (band_set == 6)
                      Write_EEPROM(twelve.EEPROM_Addr + 8, band_offset);
              else
                  if (band_set == 7)
                      Write_EEPROM(ten.EEPROM_Addr + 8, band_offset);

                  freq_counta = freq_holderql;
                  step = temp_step;
                  cal = 0;
                  //Lcd_Out(2,9,"   ");
                 //fq_upd = 1;
                 }
            }
            }
         */
         
         if (PORTA.RA4 == 0){
         
         Delay_ms(200);
         if (PORTA.RA4 == 0){
         if (Mode_set == USB){
                Mode_set = LSB;
            }
         else
         
         if (Mode_set == LSB){
                Mode_set = CWN;
            }
         else
         
         if (Mode_set == CWN){
                Mode_set = CWR;
           }
         else
                Mode_set = USB;
                
         display_mode(Mode_set);
         
         }
          }

         
       //----------Split --------------------------
       /*
       if (PORTC.RC3 == 0 && split_onoff == 1)
       
        {
         if (tx_on == 0)
           {
           freq_holderql = freq_countb;
           VFO_AB = 1;
           ad9850_wr_serial(0x00,freq_holderql);
           Display_Freq(freq_holderql);
           tx_on = 1;
           //Lcd_Out(2,2,"Tx");
           }
        //fq_upd = 1;
        Delay_ms(50);
        }

       if (PORTC.RC3 == 1 && tx_on)
         {
         ad9850_wr_serial(0x00,freq_holder);
         Display_Freq(freq_holder);
         tx_on = 0;
         VFO_AB = 0;
         //Lcd_Out(2,2,"Rx");
         fq_upd = 1;
         }
       
       //---------------RIT --------------------
       
       if (PORTC.RC3 == 0 && rit_onoff == 1)
       
        {
         if (tx_on == 0)
           {
           freq_holderql = freq_counta;
           VFO_AB = 0;
           ad9850_wr_serial(0x00,freq_holderql);
           //Display_Freq(freq_holderql, 1);
           tx_on = 1;
           //Lcd_Out(2,2,"Tx");
           }
        //fq_upd = 1;
        Delay_ms(50);
        }

       if (PORTC.RC3 == 1 && tx_on)
         {
         ad9850_wr_serial(0x00,freq_holder);
         //Display_Freq(freq_holder, 1);
         tx_on = 0;
         VFO_AB = 1;
         //Lcd_Out(2,2,"Rx");
         fq_upd = 1;
         }
        */

      //--------------------- Process Updates -------------------------------------
      
         if (fq_upd == 1)
        {
         if (VFO_AB == 0)
           {
           freq_holder = freq_counta;
           }
        else
           {
           freq_holder = freq_countb;
           }

         si5351aSetFrequency(freq_holder, 1);
         Display_Freq(freq_holder);
            
         INTCON.TMR0IF = 0;
         fq_upd = 0;
         counter = 0;
         freq_change = 1;
        }

        if (INTCON.TMR0IF == 1)
            {
            counter ++;
            INTCON.TMR0IF = 0;
            }
         if (counter == 20 && freq_change == 1)
            {

           /* if (band_set == 0)
               {
                Write_EEPROM(eighty.EEPROM_Addr, freq_counta);
                Write_EEPROM(eighty.EEPROM_Addr + 4, freq_countb);
                }
            else
            */
            if (band_set == 0)
               {
                Write_EEPROM(forty.EEPROM_Addr, freq_counta);
                Write_EEPROM(forty.EEPROM_Addr + 4, freq_countb);
                }

            if (band_set == 1)
               {
                Write_EEPROM(thirty.EEPROM_Addr, freq_counta);
                Write_EEPROM(thirty.EEPROM_Addr + 4, freq_countb);
                }

            if (band_set == 2)
               {
                Write_EEPROM(twenty.EEPROM_Addr, freq_counta);
                Write_EEPROM(twenty.EEPROM_Addr + 4, freq_countb);
                }

            if (band_set == 3)
               {
                Write_EEPROM(seventeen.EEPROM_Addr, freq_counta);
                Write_EEPROM(seventeen.EEPROM_Addr + 4, freq_countb);
                }

            if (band_set == 4)
               {
                Write_EEPROM(fifteen.EEPROM_Addr, freq_counta);
                Write_EEPROM(fifteen.EEPROM_Addr + 4, freq_countb);
                }
            /*
            if (band_set == 3)
               {
                Write_EEPROM(twelve.EEPROM_Addr, freq_counta);
                Write_EEPROM(twelve.EEPROM_Addr + 4, freq_countb);
                }

             if (band_set == 7)
               {
                Write_EEPROM(ten.EEPROM_Addr, freq_counta);
                Write_EEPROM(ten.EEPROM_Addr + 4, freq_countb);
                }
             */

             display_save() ;
             counter = 0;
             freq_change = 0;
            }


         }

 }

void Display_RIT(long rit2write)
{

 if (rit2write < 0)
   rit_display[0] =  '-' ;
 else
   rit_display[0] =   '+' ;

 rit2write = abs(rit2write);

 if (rit2write > 999)
 {
   rit_display[1] =  (rit2write/1000)%10 + 48;
   //rit_display[2] =  '.';
   }
 else
   {
   rit_display[1] =   '0' ;
   //rit_display[1] =  ' ';
   }
   rit_display[2] =  '.';
   rit_display[3] =  (rit2write/100)%10 + 48;
   rit_display[4] =  (rit2write/10)%10 + 48;
   //Lcd_Out(2,6, rit_display);

}

void Write_EEPROM(unsigned int wr_addr,  unsigned long wr_data)
{
              //EEPROM Write Freq Routine

         EEPROM_Write(wr_addr, Lo(wr_data));
         EEPROM_Write(wr_addr+1, Hi(wr_data));
         EEPROM_Write(wr_addr+2, Higher(wr_data));
         EEPROM_Write(wr_addr+3, Highest(wr_data));
         Delay_ms(20);


}

unsigned long int Read_EEPROM(unsigned int rd_addr)
{
   unsigned long rd_freq;

    Lo(rd_freq) = EEPROM_Read(rd_addr);
    Hi(rd_freq) = EEPROM_Read(rd_addr+1);
    Higher(rd_freq) = EEPROM_Read(rd_addr+2);
    Highest(rd_freq) = EEPROM_Read(rd_addr+3);
    Delay_ms(20);
    return rd_freq;
}

  int convertLongToBytes( unsigned char *convBytes, unsigned long target)
{
        unsigned char i;

    for(i=0; i < 4; i++)
    {
                convBytes[i] = target;
                target = target >> 8;
        }

         return i;
}