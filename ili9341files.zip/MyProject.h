// Routines for si5351 project


//-------------Subroutines --------------------

void Display_RIT(long rit2write);
void Write_EEPROM(unsigned int wr_addr , unsigned long int wr_data);
unsigned long int Read_EEPROM(unsigned int rd_addr);
int convertLongToBytes( unsigned char * convBytes, unsigned long target);
void Set_Mode(unsigned int mode);
unsigned long int BFO_Cal(unsigned long int bfo_freq);
void Get_Keypad(void);
