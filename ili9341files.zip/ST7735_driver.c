// OLED Display SPI Driver
//
//
// ST7735 TFT
// SPI interface for controlling TFT Display
// Adapted from software posted by Bruce Hall W8BH
#include "fonts.h"
#include "ST7735_driver.h"
#include "display_160x128TFT.h"
#include "meters.h"

char    digit[9];                  // Decimal digits for frequency 0..8
char    blank;                     // Leading zero supression
char    rx_mtr_active;             // S-Meter in use flag
char    tx_mtr_active;             // Tx Meter is use

unsigned int    disp_update;       // Display refresh counter
unsigned int    s_meter_update;    // S-Meter refresh counter
int             agc_dB_offset;     // Offset in dB for display calibration
int             agc_dB_last;       // Previous signal level value

// Flags
int   rit_flag;                    // RIT, 0=OFF, 1=ON
int   fixed_rate;                  // Tuning rate, 0=slow, 1=fast
int   var_rate;                    // Variable rate tuning, 0=off, 1=on
int   tuning_lock;                 // Encoder A lock state 0=unlocked, 1=locked

unsigned int  colour;               // 16 bit pixel colour
unsigned int  backgnd;              // 16 bit background colour
unsigned char font, spacing;        // Text style and attributes
unsigned int xs, ys, xe, ye;       // X and Y start and end range co-ordinates (defines a rectangular area)
unsigned int xmax, ymax;           // Display area limits in pixels (set by orientation)
// 16 bit SPI Interface
// 5 wire uni-directional interface comprising of Data, Clock, Chip select, Latch and Reset.
// MSb seet first. Pin definitions in h file.
// See ST7735 data sheet for description and timings.

void  write_disp_SPI16(unsigned disp_word){
        unsigned char i;                        // Declare Counter
        DISP_SCLK=0;                            // Clock Low
        DISP_CS=0;                              // Latch Low
            for(i=0; i<16; ++i){                // 16 bit data send loop
                if(disp_word & 0x8000)          // Test state of MSB by ANDing MSb bit with 1
                        DISP_SDIN=1;            // High, set data out state
                else                            //
                        DISP_SDIN=0;            // Low, clear data out bit
                disp_word=disp_word<<1;         // Shift data word left 1 bit
                DISP_SCLK=1;                        // Raise Clock line to load bit into MCP6S21
                asm nop;                        // Pause to allow change to settle
                asm nop;                       //
                DISP_SCLK=0; 
                                       // Drop clock line
                }                                // Back round again
        asm nop;                             // Pause to allow change to settle
        asm nop;                             //

        DISP_CS=1;                                // Raise latch line to instruct transfer of byte
}

// 8 bit SPI Interface
// 5 wire uni-directional interface comprising of Data, Clock, Chip select, Latch and Reset.
// MSb seet first. Pin definitions in h file.
// See SSD1306 data sheet for description and timings.

void write_disp_SPI8(unsigned char disp_byte){
        unsigned char i;                        // Declare Counter
        DISP_SCLK=0;                            // Clock Low
        DISP_CS=0;                              // Latch Low
            for(i=0; i<8; ++i){                 // 8 bit data send loop
                if(disp_byte & 0x80)            // Test state of MSB by ANDing MSb bit with 1
                        DISP_SDIN=1;            // High, set data out state
                else                            //
                        DISP_SDIN=0;            // Low, clear data out bit
                disp_byte=disp_byte<<1;         // Shift data word left 1 bit
                DISP_SCLK=1;                        // Raise Clock line to load bit into MCP6S21
                asm nop;                        // Pause to allow change to settle
                asm nop;                        //
                DISP_SCLK=0;                        // Drop clock line
                }                                // Back round again
        asm nop;                             // Pause to allow change to settle
        asm nop;                             //

        DISP_CS=1;                                // Raise latch line to instruct transfer of byte
}

//
// Display Routines
//
void disp_com(unsigned char disp_byte){         // Send an instruction
    DISP_DC=0;                                  // Set DC for command
    write_disp_SPI8(disp_byte);                 // Send over SPI
}

void disp_byte(unsigned disp_char ){             // Send data for display
    DISP_DC=1;                                  // Set DC for data
    write_disp_SPI8(disp_char);                      // Data
}

void disp_word(int char_data){                       // Write a 16 bit value to teh display
    DISP_DC=1;                                  // Set DC for data
    write_disp_SPI16(char_data);                     // Data
}

void disp_colour(unsigned int foregnd, unsigned int back){
    colour=foregnd;
    backgnd=back;
}

// Define rectangular area within which the pixels will be plotted
// Horizontal range, xs..xe, vertical range ys..ye. The x and y range
// values are defined by the calling routine.
void disp_addr_win(){
    disp_com(CASET);        // Set column range (xs,xe)
    disp_word(0x0000|xs);   // X start
    disp_word(0x0000|xe);   // X end
    disp_com(RASET);        // Set row range (ys,ye)
    disp_word(0x0000|ys);   // Y start
    disp_word(0x0000|ye);   // Y end
}
// For use with basic 5x7 text the display addresses are configured as 20 rows
// (160/8) and 128 columns. This addressing is used by the calling routine to
// set a row (line) and horizontal position for text.

void disp_addr(unsigned char page, unsigned char col){     // Set start position xs, ys
    xs=col;                // X start is column number
    ys=page<<3;            // Y start is page (line) number*8 (bits high)
}

// Set font and spacing
void disp_font(unsigned char font_type, unsigned char chr_space){
    font=font_type;
    spacing=chr_space;
}

// Print character with spacing
void disp_chr(unsigned char chr){       // Display wxh size character
    unsigned char   sp;                 // Inter character space
    unsigned char   chr_addr;           // Font table row address
    unsigned char   i;                  // Index
    unsigned char   col;                // Index
    unsigned char   row;                // Index
    unsigned char   byte;               // Horizontal data
    unsigned char   mask;               // Bit mask for extracting pixels
    unsigned char   bit_data;               // Byte of character to be sent
    unsigned int    pixel;              // 16 bit pixel colour data
    unsigned char   counter;
    chr_addr=chr-32;                    // Remove ASCII offset to align table

    DISP_DC=1;                          // Set DC high

    switch(font){

        case 0:                                       // 5x8 characters written in row order
            sp=(spacing+SP0);                         // Get intercharacter space
            mask=1;                                   // Start mask at 1
            xe=xs+4+sp;                               // Set display area boundaries for character
            ye=ys+7;                                  // by adding width and height to start points
            disp_addr_win();                          // Send x and y ranges
            disp_com(RAMWR);                          // Send RAM write command for following data
            DISP_DC=1;                                // Set display for data
            for(row=0;row<8;row++){                   // Write each horizontal row
            for(col=0;col<5;col++){                   // Write each pixel on row as 16bit colour
                bit_data=font5x8[chr_addr][col];          // Get character col
                bit_data=bit_data & mask;                     // Mask off bit
                if(!bit_data){pixel=backgnd;}             // If bit clear set pixel colour to background
                else{pixel=colour;}                   // Otherwise set to colour
                write_disp_SPI16(pixel);
                             // Send 16 bit pixel data
                }
            for(i=0;i<sp;i++){                        // Append any spaces to end of character
                write_disp_SPI16(backgnd);
                }
            mask=mask<<1;                             // Next row
            }
            xs=xe+1;                                  // Point to start of next character area (y0 unchanged)
            break;

        case 1:                                       // 8x16 characters
            sp=(spacing+SP1);                         // Get intercharacter space
            mask=1;                                   // Start mask at 1
            xe=xs+7+sp;                               // Set display area boundaries for character
            ye=ys+16;                                 // by adding width and height to start points
            disp_addr_win();                          // Send x and y ranges
            disp_com(RAMWR);                          // Send RAM write command for following data
            DISP_DC=1;                                // Set display for data
            // Write top half of 8x16 character (rows 0..7)
            for(row=0;row<8;row++){                   // Write each horizontal row
            for(col=0;col<8;col++){                   // Write each pixel on row as 16bit colour
                bit_data=font8x16[chr_addr][col];         // Get character col
                bit_data=bit_data & mask;                     // Mask off bit
                if(!bit_data){pixel=backgnd;}             // If bit clear set pixel colour to background
                else{pixel=colour;}                   // Otherwise set to colour
                write_disp_SPI16(pixel);              // Send 16 bit pixel data
                }
            for(i=0;i<sp;i++){                        // Append any spaces to end of character
                write_disp_SPI16(backgnd);
                }
            mask=mask<<1;                             // Next row
            }
            // Write lower half of 8x16 character (rows 8..15)
            mask=1;
            for(row=8;row<16;row++){                  // Write each horizontal row
            for(col=8;col<16;col++){                   // Write each pixel on row as 16bit colour
                bit_data=font8x16[chr_addr][col];         // Get character col
                bit_data=bit_data & mask;                     // Mask off bit
                if(!bit_data){pixel=backgnd;}             // If bit clear set pixel colour to background
                else{pixel=colour;}                   // Otherwise set to colour
                write_disp_SPI16(pixel);              // Send 16 bit pixel data
                }
            for(i=0;i<sp;i++){                        // Append any spaces to end of character
                write_disp_SPI16(backgnd);
                }
            mask=mask<<1;                             // Next row
            }
            xs=xe+1;                                  // Point to start of next character area (y0 unchanged)

            break;

         case 3:
            // 8x16 font is "trimmed down" by selecting only cental portion containing
            // bitmap data. In effect, leading and trailing blanks are discarded.
            // 8x16 character is printed in two halves, upper 8 bits and lower 8 bits
            // To be able to start the lower half at the correct point we must record
            // the start position of the top half in terms of initial segment and pixel.

            sp=(spacing+SP0);                         // Get intercharacter space
            mask=1;                                   // Start mask at 1
            xe=xs+2+sp;                               // Set display area boundaries for character
            ye=ys+15;                                 // by adding width and height to start points
            disp_addr_win();                          // Send x and y ranges
            disp_com(RAMWR);                          // Send RAM write command for following data
            DISP_DC=1;                                // Set display for data
            // Write top half of 8x16 character (rows 0..7)
            for(row=0;row<8;row++){                   // Write each horizontal row
            for(col=2;col<5;col++){                   // Write each pixel on row as 16bit colour
                bit_data=font8x16[chr_addr][col];         // Get character col
                bit_data=bit_data & mask;                     // Mask off bit
                if(!bit_data){pixel=backgnd;}             // If bit clear set pixel colour to background
                else{pixel=colour;}                   // Otherwise set to colour
                write_disp_SPI16(pixel);              // Send 16 bit pixel data
                }
            for(i=0;i<sp;i++){                        // Append any spaces to end of character
                write_disp_SPI16(backgnd);
                }
            mask=mask<<1;                             // Next row
            }
            // Write lower half of 8x16 character (rows 8..15)
            mask=1;
            for(row=8;row<16;row++){                  // Write each horizontal row
            for(col=10;col<13;col++){                   // Write each pixel on row as 16bit colour
                bit_data=font8x16[chr_addr][col];         // Get character col
                bit_data=bit_data & mask;                     // Mask off bit
                if(!bit_data){pixel=backgnd;}             // If bit clear set pixel colour to background
                else{pixel=colour;}                   // Otherwise set to colour
                write_disp_SPI16(pixel);              // Send 16 bit pixel data
                }
            for(i=0;i<sp;i++){                        // Append any spaces to end of character
                write_disp_SPI16(backgnd);
                }
            mask=mask<<1;                             // Next row
            }
            xs=xe+1;                                  // Point to start of next character area (y0 unchanged)

            break;
        // Large format numbers for frequency display
        /*
        case 4:
            if(chr_addr>0){
            chr_addr=chr_addr-15;                     // Normalise addressing to cut down table
            }
            sp=(spacing+SP3);                         // Get intercharacter space
            xe=xs+11+sp;                               // Set display area boundaries for character
            ye=ys+17;
            //xe=xs+23+sp;                               // Set display area boundaries for character
            //ye=ys+34;
                                             // by adding width and height to start points
            disp_addr_win();                          // Send x and y ranges
            disp_com(RAMWR);                          // Send RAM write command for following data
            DISP_DC=1;                                // Set display for data
            for(byte=0;byte<34;byte=byte+2){          // Write each horizontal row of two bytes
                
                mask=1;                               // Start mask at 1
                bit_data=font12x17num[chr_addr][byte];    // Get character byte
                                                                 // Write first 8 pixels on row
                for(i=0;i<8;i++){                     // Test byte bits and plot as pixels
                    if(!(bit_data&mask)){pixel=backgnd;}  // If bit clear set pixel colour to background
                    else{pixel=colour;}               // Otherwise set to colour
                write_disp_SPI16(pixel);              // Send 16 bit pixel data
                mask=mask<<1;                         // Next bit
                }
                // Write remaining 4 pixels on row
                mask=1;
                bit_data=font12x17num[chr_addr][byte+1];  // Get character byte
                for(i=0;i<4;i++){                     // Test byte bits and plot as pixels
                    if(!(bit_data&mask)){pixel=backgnd;}  // If bit clear set pixel colour to background
                    else{pixel=colour;}               // Otherwise set to colour
                write_disp_SPI16(pixel);              // Send 16 bit pixel data
                
                //write_disp_SPI16(pixel);
                mask=mask<<1;                         // Next bit
                }
                for(i=0;i<sp;i++){                        // Append any spaces to end of character
                    write_disp_SPI16(backgnd);
                    //write_disp_SPI16(backgnd);
                    }
            }
            xs=xe+1;                                  // Point to start of next character area (y0 unchanged)           
            break;
         */

         case 4:
            if(chr_addr>0){
            chr_addr=chr_addr-15;                     // Normalise addressing to cut down table
            }
            sp=(spacing+SP3);                         // Get intercharacter space
            //xe=xs+11+sp;                               // Set display area boundaries for character
            //ye=ys+17;
            xe=xs+23+sp;                               // Set display area boundaries for character
            ye=ys+34;
                                             // by adding width and height to start points
            disp_addr_win();                          // Send x and y ranges
            disp_com(RAMWR);                          // Send RAM write command for following data
            DISP_DC=1;                                // Set display for data
            for(byte=0;byte<34;byte=byte+2){          // Write each horizontal row of two bytes
                                              // Start mask at 1
                //bit_data=font12x17num[chr_addr][byte];    // Get character byte
            for(counter=0;counter<2;counter++){
              
              for(counter=0;counter<2;counter++){                                                   // Write first 8 pixels on row
              bit_data=font12x17num[chr_addr][byte];
              mask=1;
                 for(i=0;i<8;i++){                     // Test byte bits and plot as pixels
                    if(!(bit_data&mask)){pixel=backgnd;}  // If bit clear set pixel colour to background
                    else{pixel=colour;}               // Otherwise set to colour
                write_disp_SPI16(pixel);              // Send 16 bit pixel data
                mask=mask<<1;                         // Next bit
                }
                }
                
                 // Get character byte  // Write remaining 4 pixels on row
                
                for(counter=0;counter<2;counter++){
                mask=1;
                bit_data=font12x17num[chr_addr][byte+1];
                for(i=0;i<4;i++){                     // Test byte bits and plot as pixels
                    if(!(bit_data&mask)){pixel=backgnd;}  // If bit clear set pixel colour to background
                    else{pixel=colour;}               // Otherwise set to colour
                write_disp_SPI16(pixel);              // Send 16 bit pixel data
                mask=mask<<1;                         // Next bit
                }
                }
                
                //for(counter=0;counter<2;counter++){
                for(i=0;i<sp;i++){                        // Append any spaces to end of character
                    write_disp_SPI16(backgnd);
                    }
                //}
                }
            }
            xs=xe+1;                                  // Point to start of next character area (y0 unchanged)
            break;



         // Large format Narrow symbols (5x17)
         case 5:
            sp=(spacing+SP3);                         // Get intercharacter space
            xe=xs+4+sp;                               // Set display area boundaries for character
            ye=ys+17;                                 // by adding width and height to start points
            disp_addr_win();                          // Send x and y ranges
            disp_com(RAMWR);                          // Send RAM write command for following data
            DISP_DC=1;                                // Set display for data
            for(byte=0;byte<17;byte++){               // Write each horizontal row of 5 bits
                mask=1;                               // Start mask at 1
                bit_data=font12x17nar[chr_addr][byte];    // Get character byte
                // Write 5 pixels on row
                for(i=0;i<5;i++){                     // Test byte bits and plot as pixels
                    if(!(bit_data&mask)){pixel=backgnd;}  // If bit clear set pixel colour to background
                    else{pixel=colour;}               // Otherwise set to colour
                write_disp_SPI16(pixel);              // Send 16 bit pixel data
                mask=mask<<1;                         // Next bit
                }
                for(i=0;i<sp;i++){                    // Append any spaces to end of character
                    write_disp_SPI16(backgnd);
                    }
            }
            xs=xe+1;                                  // Point to start of next character area (y0 unchanged)
            break;
    }
}

// Set the display orientation to 0,90,180,or 270 degrees
void disp_orientation(int degrees){
    unsigned char ang;

    switch (degrees){                   // Select orientation factor
        case 90:    ang = 0x28    ;         // Landscape     0x60
                    xmax=319;           // 160 pixels wide (0..159)
                    ymax=239;           // 128 pixels high (0..127)
                    break;

        case 180:   ang = 0xC0;         // Portrait
                    xmax=159;           // 128 pixels wide (0..127)
                    ymax=127;           // 160 pixels high (0..159)
                    break;
        case 270:   ang = 0xA0;         // Landscape
                    xmax=159;           // 160 pixels wide (0..159)
                    ymax=127;           // 128 pixels high (0..127)        
                    break;

        default:    ang = 0x00;         // Portrait
                    xmax=127;           // 128 pixels wide (0..127)
                    ymax=159;           // 160 pixels high (0..159)
                    break;
        }
    disp_com(MADCTL);                   // Send to Memory Data Access Control
    disp_byte(ang);                     // to change scan order
}

// Send character string string. Send each component of the string
// array to the display until an end "null" character is met.
void disp_str(register const char *str){
    while(*str){                                        // Test current character for "null"
    disp_chr(*str);                                     // Write character
    str++;}                                             // Increment array counter
}

void disp_gra(unsigned char byte){
    unsigned char   chr_addr;           // Font table row address
    unsigned char   i;                  // Index
    unsigned char   col;                // Index
    unsigned char   row;                // Index
    unsigned char   byte;               // Horizontal data
    unsigned char   mask;               // Bit mask for extracting pixels
    unsigned char   bit_data;               // Byte of character to be sent
    unsigned int    pixel;              // 16 bit pixel colour data


            mask=1;                                   // Start mask at 1

            DISP_DC=1;                                // Set display for data
            for(row=0;row<16;row++){                   // Write each horizontal row
            for(col=0;col<98;col++){                   // Write each pixel on row as 16bit colour
                bit_data=s_mtr_scale[col];         // Get character col
                bit_data=bit_data & mask;                     // Mask off bit
                if(!bit_data){pixel=backgnd;}             // If bit clear set pixel colour to background
                else{pixel=colour;}                   // Otherwise set to colour
                write_disp_SPI16(pixel);              // Send 16 bit pixel data
                }
               mask=mask<<1;                             // Next row
              }
 }
void disp_write(){
    
}

void disp_clr(){
    unsigned long int i;                     // Loop index
    xs=0;
    xe=xmax;
    ys=0;
    ye=ymax;
    disp_addr_win();       // Set window to entire display
    disp_com(RAMWR);                    // Send RAM write command
    DISP_DC=1;
    for (i=76800;i>0;--i){              // Word count = 128*160
        write_disp_SPI16(BLACK);
        }
}

void init_disp(){                                       // Initialise DISP
    // Prepare Port Pins
    //TRISB=TRISB&DISP_SPI_DIR;
    DISP_RES=0;                     // Take reset line low
    Delay_ms(1);                    // Wait
    DISP_RES=1;                     // Take reset line high
    Delay_ms(200);                  // Wait for action to complete
    disp_com(SLPOUT);               // Take display out of sleep mode
    Delay_ms(150);                  // Wait 150mS for TFT driver circuits
    disp_com(COLMOD);               // Select colour mode:
    disp_byte(0x05);                // Mode 5; 16bit pixels (RGB565)
    disp_com(DISPON);               // Turn display on
    disp_colour(WHITE,BLACK);
    disp_orientation(90);
    disp_clr();
}
// Start up screens



// Draw the S-Meter scale and bar graph representation of AGC voltage. Increments are
// in 1dB with scale graticule divisions every 6dB up to S9, 10dB up to +20dB and 10dB
// every 5 increments up to +50dB. Total number of increments for FSD are;
// 9*6+20+15=89
//

void rx_meter(unsigned int agc_dB){                        // S Meter
    unsigned char   bit_data;
    unsigned char i;                    // Loop index
    char dB_diff;                       // Calculate difference between current and last AGC
    char plot_start;                    // Start position for graph update
    unsigned char   mask;
    unsigned int    pixel;
    unsigned char   col;                // Index
    unsigned char   row;                // Index
    
        agc_dB = agc_dB/5;
        /*
        if(agc_dB>(linear_dB[45])){    // Test for mid point in table
            i=37;                       // Greater than mid point, start from here
        }
        else{
        i=0;                            // Less than mid point, start from zero
        }
        do{
            i++;                        // Increment pointer until it the table entry
        }
        
        while(agc_dB>(linear_dB[i])); // equals or exceeds agc_det value

     agc_dB=i*3; //+codec_gain;               // Add in CODEC gain
     */
     // Look for change and only update that portion of the scale that has changed
     s_meter_update = 0; //--;                          // Decrement update counter
     if(!s_meter_update){                       // Are we at zero?
         s_meter_update=S_MTR_UPD;              // Yes, reload counter and refresh meter
     
     disp_addr(BAR,MTR_START);
     xe=xs+189;                               // Set display area boundaries for character
     ye=ys+15;                                 // by adding width and height to start points
     disp_addr_win();                          // Send x and y ranges
     disp_com(RAMWR);                          // Send RAM write command for following data
     DISP_DC=1;
     mask=1;
     agc_dB_last=agc_dB;

         for(row=0;row<16;row++){                   // Write each horizontal row
              agc_dB = agc_dB_last;
             for(col=0;col<190;col++){
                if(agc_dB > 0)
                     {                                          // If dB value >0, fill bar              // Set display for data
                     bit_data= 0xff ;//mtr_fill_bar[col];
                     if(col > 129){disp_colour(GREEN,BLACK);}
                     else disp_colour(RED,BLACK);
                     agc_dB--;
                     }
                else
                     {
                     bit_data=mtr_empty_bar[col];
                     colour = WHITE;
                     }
                bit_data=bit_data & mask;                     // Mask off bit

                if(!bit_data){pixel=backgnd;}             // If bit clear set pixel colour to background
                else{pixel=colour;}                   // Otherwise set to colour
                write_disp_SPI16(pixel);
                          // Decrement dB count
                } 
         mask=mask<<1;
      }
      //mask=1;
      }
   disp_colour(WHITE,BLACK);                          // Update historic value
}

// Draw scale and empty bar (do this once upon entering Rx)
void rx_meter_scale(){

    unsigned char   chr_addr;           // Font table row address
    unsigned char   i;                  // Index
    unsigned char   col;                // Index
    unsigned char   row;                // Index
    unsigned char   byte;               // Horizontal data
    unsigned char   mask;               // Bit mask for extracting pixels
    unsigned char   bit_data;               // Byte of character to be sent
    unsigned int    pixel;              // 16 bit pixel colour data
    
    mask=1;                                   // Start mask at 1
    disp_addr(RXSCALE,MTR_START);
    xe=xs+191;                               // Set display area boundaries for character
    ye=ys+15;                                 // by adding width and height to start points
    disp_addr_win();                          // Send x and y ranges
    disp_com(RAMWR);                          // Send RAM write command for following data
    DISP_DC=1;

            //disp_colour(WHITE,BLACK);                       // Set display for data
            for(row=0;row<16;row++){                   // Write each horizontal row
            for(col=0;col<192;col++){                   // Write each pixel on row as 16bit colour
                bit_data=s_mtr_scale[col];         // Get character col
                bit_data=bit_data & mask;                     // Mask off bit
                if(!bit_data){pixel=backgnd;}             // If bit clear set pixel colour to background
                else
                pixel=colour;                     // Otherwise set to colour
                write_disp_SPI16(pixel);          // Send 16 bit pixel data
                }
               mask=mask<<1;                             // Next row
              }
      disp_colour(WHITE,BLACK);
      mask=1;

    disp_addr(BAR,MTR_START);
    xe=xs+191;                               // Set display area boundaries for character
    ye=ys+15;                                 // by adding width and height to start points
    disp_addr_win();                          // Send x and y ranges
    disp_com(RAMWR);                          // Send RAM write command for following data
    DISP_DC=1;
    for(row=0;row<16;row++){                   // Write each horizontal row
            for(col=0;col<192;col++){                   // Write each pixel on row as 16bit colour
                bit_data=mtr_empty_bar[col];         // Get character col
                bit_data=bit_data & mask;                     // Mask off bit
                if(!bit_data){pixel=backgnd;}             // If bit clear set pixel colour to background
                else{pixel=colour;}                   // Otherwise set to colour
                write_disp_SPI16(pixel);              // Send 16 bit pixel data
                }
               mask=mask<<1;                             // Next row
              }                       // Point to bar start
 }

void freq_format(){

      disp_colour(WHITE,BLACK);

      if (digit[7]==0x30){                          // Leading zero supression
         disp_chr(0x20);                            // Blank character position
      }
       else {disp_chr(digit[7]);}                   // Show 10MHz

       disp_chr(digit[6]);                          // Show MHz
       disp_font(FONT12x17NAR,NORMAL);              // Narrow font
       disp_chr(DP12x17);                           // Show Decimal Point
       disp_font(FONT12x17NUM,NORMAL);
       disp_chr(digit[5]);                          // Show 100kHz
       disp_chr(digit[4]);                          // Show 10kHz
       disp_chr(digit[3]);                          // Show kHz
       disp_font(FONT12x17NAR,NORMAL);               // Narrow font
       disp_chr(COMMA12x17);                        // Show comma
       disp_font(FONT12x17NUM,NORMAL);
       disp_chr(digit[2]);                          // show 100s Hz
       disp_chr(digit[1]);                          // Show 10s Hz
       disp_colour(WHITE,BLACK);
 }

void rit_format(){
      if (digit[4]==0x30){                          // Leading zero supression
         disp_chr(0x20);}                           // Blank character position
      else {disp_chr(digit[4]);}                    // No zero, show 10kHz
                                                    // No leading zero supression from here
      disp_chr(digit[3]);                           // Show kHz
      disp_chr(0x2E);                               // Put kHz Decimal Point here
      disp_chr(digit[2]);                           // show 100s Hz
      disp_chr(digit[1]);                           // Show 10s Hz
      disp_str("kHz");                              // Print kHz
 }
// Convert binary value held in "n" into BCD digits for display

void binary_BCD(unsigned long n){                                  //

    unsigned long    decade;                        // Decade value
    unsigned int     i;                             // Declare temporary index

    decade=100000000;                               // Start value (maximum decade, 10^8)
    i=8;                                            // Point digit index to MSD
    do{                                             // Inner decade loop
    digit[i]=0x30;                                  // Initialise decade value at ASCII zero
    while(n>=decade){                               // Calculate decade value
        n=n-decade;                                 // Subtract decade from f
        digit[i]++;                                 // Increment digit decade count
        }
    decade=decade/10;                               // Next lower decade
    i--;                                            // Decrement digit index
    }while (i>0);                                   // Exit when i=0
}

// Converion of an 8 bit value to decimal, resul in digit[2..0]
void binary_BCD_byte(unsigned n){
    unsigned long    decade;                        // Decade value
    int     i;                                      // Declare temporary index

    decade=100 ;                                    // Start value (maximum decade, 10^2)
    i=2;                                            // Point digit index to MSD
    do{                                             // Inner decade loop
    digit[i]=0x30;                                  // Initialise decade value at ASCII zero
    while(n>=decade){                               // Calculate decade value
        n=n-decade;                                 // Subtract decade from f
        digit[i]++;                                 // Increment digit decade count
        }
    decade=decade/10;                               // Next lower decade
    i--;                                            // Decrement digit index
    }while (i>=0);                                  // Exit when i<0
}

void Display_Freq(unsigned long freq){              // Send frequency data to display
    disp_addr(6,48);
    disp_font(FONT12x17NUM,NORMAL);
    binary_BCD(freq);                               // Convert the binary frequency word to BCD
    blank=0;                                        // Clear blanking flag
    freq_format();
}

void display_MHz(){
    disp_colour(YELLOW,BLACK);                                 // Add "MHz" to initial display (not updated with frequency)
    disp_font(FONT8x16,NORMAL);                     //
    disp_str("MHz");
    disp_colour(WHITE,BLACK);                                //
}
void display_vfo(){                                 // Add "MHz" to initial display (not updated with frequency)
    disp_font(FONT8x16,NORMAL);                     //
    disp_addr(0,10);
    disp_str("VFO");                                //
}
void display_ab(int ab){
    disp_font(FONT8x16,NORMAL);                     //
    disp_addr(0,45);
    if (ab == 0)
      disp_str("A");
    else
      disp_str("B");
    }
void display_rate(int new_step){                                // Display tuning rate
    int step;
    step = new_step;
    disp_font(FONT8x16,NORMAL);  // Set font
    disp_addr(0,248);            // Point to lock  state address
    /*
    if(tuning_lock){            // If locked
        disp_str("LOCK ");       // Display LOCK
        }
    else if(var_rate){          // Otherwise if variable rate enabled
        disp_str("VAR  ");       // Show VAR
    }
    else{                       // If we are in fixed rate show tuning rate
    */    if(step ==100)         //
            disp_str("100Hz");   // Show FAST

        else{
            disp_str(" 10Hz");   // Show SLOW
            }

}
/*
void display_agc(){             // Show AGC state
    disp_addr(9,4);             // Point to AGC area
    disp_font(FONT5x8,NORMAL);  // Set up font
    disp_str("AGC");
    disp_addr(10,0);             // Point to AGC area
    switch (agc_mode){
        case AGC_ON_FAST:
        disp_str("FAST");
        break;

        case AGC_ON_SLOW:
        disp_str("SLOW");
        break;

        case AGC_OFF:
        disp_str("OFF ");
        break;
    }
}

void display_rit(signed long rit_freq){ // Show RIT offset
    unsigned long rit_abs;
    disp_addr(7,70);            // Point to RIT area
    disp_font(FONT5x8,NORMAL);  // Set up font
    disp_str("RIT");            // Print RIT
    if(rit_flag){               // If RIT ON
    if(rit_freq>0){             // If positive, prefix with "+"
        disp_str("+");
        }
    else if(rit_freq<0){         // If negative, pefix with "-"
            disp_str("-");
        }
    else if(rit_freq==0){
            disp_str(" ");      // If zero, prefix with a blank
        }
    rit_abs=abs(rit_freq);       // Convert to absolute value
    binary_BCD(rit_abs);         // Convert the binary frequency word to BCD
    rit_format();                // Display RIT value
    }
    else{                        // RIT OFF, clear display area
    disp_str(" OFF     ");       // Clear frequency
    }
}

// Display Setting
//
// Character field 8 chrs wide
void display_setting(unsigned int setting){
    disp_addr(7,2);             // OLED address for function display
    disp_font(FONT5x8,NORMAL);
    disp_colour(RED,BLACK);

    switch (setting){           // Display current function
        case SET_CAL:
            disp_str("VFO CAL ");
            break;

        case SET_RX_BAL:
            disp_str("RX I/Q  ");
            break;

        case SET_TX_BAL:
            disp_str("TX I/Q  ");
            break;

        case SET_MIC_GAIN:
            disp_str("MIC GAIN");
            break;

        case SET_MIC_PRE:
            disp_str("MIC PRE ");
            break;

        case SET_IQ_SWAP:
            disp_str("I/Q SWAP");
            break;
    }
    disp_colour(WHITE,BLACK);
}

// Display submenu associated with current setting
//
void display_submenu(setting){


}

// Display function setting
//
// Character field 8 chrs wide
void display_function(unsigned int function){
    disp_addr(7,2);             // OLED address for function display
    disp_font(FONT5x8,NORMAL);

    switch (function){          // Display current function
        case FUNC_BAND:
            disp_str("BAND    ");
            break;

        case FUNC_MODE:
            disp_str("MODE    ");
            break;

        case FUNC_FILTER:
            disp_str("FILTER  ");
            break;

        case FUNC_AGC:
            disp_str("AGC     ");
            break;
    }
}

// Display operating mode
void display_mode(unsigned int mode){
    disp_addr(0,70);
    disp_font(FONT5x8,NORMAL);

    switch (mode){
        case USB:
        disp_str("USB");
        break;

        case LSB:
        disp_str("LSB");
        break;

        case CW:
        disp_str("CWN");
        break;

        case CWR:
        disp_str("CWR");
        break;
    }
}

// Display VFO Calibration rate
void display_cal(int cal_rate){
    disp_addr(4,2);
    disp_font(FONT5x8,NORMAL);

    if(cal_rate){                               //
        disp_str("Calfast ");                    // Fast tuning rate
    }
        else{
        disp_str("Calfine ");                    // Fine tuning rate
    }
}

// Display gain and phase compensation
void display_comp(int comp_type){
    disp_addr(4,2);
    disp_font(FONT5x8,NORMAL);

    if(!comp_type){                              //
        disp_str("Gain    ");
    }
        else{
        disp_str("Phase   ");
    }
}
// Display I/Q swap states
void display_rx_IQ_swap(int rx_iq_swap){
    disp_addr(4,2);
    disp_font(FONT5x8,NORMAL);

        if(!rx_iq_swap){
            disp_str("Rx Norm ");
        }
        else{
            disp_str("Rx Swap ");
        }
}

void display_tx_IQ_swap(int tx_iq_swap){
    disp_addr(4,2);
    disp_font(FONT5x8,NORMAL);

        if(!tx_iq_swap){
            disp_str("Tx Norm ");
        }
        else{
            disp_str("Tx Swap ");
        }
}
// Display Mic gain in dB, allowing for +20dB fixed gain
void display_mic_gain(signed int mic_dB){

    unsigned int mic_dB_abs;        // Absolute value for display

    disp_addr(4,2);
    disp_font(FONT5x8,NORMAL);

    mic_dB=mic_dB-MIC_FIXED_GAIN;   // Account for fixed CODEC gain

    disp_str("Mic");                // Print "Mic"
    if(mic_dB>0){                   // If positive, prefix with "+"
        disp_str("+");
        }
    else if(mic_dB<0){              // If negative, pefix with "-"
            disp_str("-");
        }
    else if(mic_dB==0){
            disp_str(" ");          // If zero, prefix with a blank
        }
    mic_dB_abs=abs(mic_dB);         // Convert to absolute value
    binary_BCD_byte(mic_dB_abs);    // Convert the binary frequency word to BCD
    // Display Mic gain in dB with leading zero blanking
    if(digit[1]==0x31){             // If digit set to ASCII 1
    disp_chr(digit[1]);             // Print value
    }
    else{                           // If digit 1=0x30
        disp_str(" ");              // Print blank
    }
    disp_chr(digit[0]);             //
    disp_str("dB");                 // Add dB
}

void display_mic_pre(unsigned int mic_pre){

    disp_addr(4,2);
    disp_font(FONT5x8,NORMAL);      //

    binary_BCD_byte(mic_pre);       // Convert the binary frequency word to BCD
    disp_str("Pre   ");             // Print "Pre "
    // Display Mic pre-emph index with leading zero blanking
    if(digit[1]==0x31){             // If set to ASCII 1
        disp_chr(digit[1]);         // Print value
    }
    else{
        disp_str(" ");              // If zero print blank
    }
    disp_chr(digit[0]);             //
}

// Display filter
void display_filter(unsigned int filter){
    disp_addr(0,54);
    disp_font(FONT5x8,NORMAL);
    switch (filter){
        case SSB_1:
        disp_str("2.8kHz");
        break;

        case SSB_2:
        disp_str("2.5kHz");
        break;

        case SSB_3:
        disp_str("2.2kHz");
        break;

        case SSB_4:
        disp_str("2.0kHz");
        break;

        case SSB_5:
        disp_str("1.8kHz");
        break;

        case CW_1:
        disp_str("500Hz ");
        break;

        case CW_2:
        disp_str("350Hz ");
        break;

        case CW_3:
        disp_str("300Hz ");
        break;

        case CW_4:
        disp_str("200Hz ");
        break;
    }
}
*/
// Display Tx/Rx State

void display_meterscale(){
    disp_addr(DB_SCALE,65);                 // TR area display address
    disp_font(FONT8x16,NORMAL);
    disp_str("1");      //
    disp_addr(DB_SCALE,95);
    disp_str("3");
    disp_addr(DB_SCALE,125);
    disp_str("5");
    disp_addr(DB_SCALE,155);
    disp_str("7");
    disp_addr(DB_SCALE,185);
    disp_str("9");
    disp_addr(DB_SCALE,210);
    disp_str("20");  
    disp_addr(DB_SCALE,245);
    disp_str("40");                //
}

void display_rx(){
    disp_addr(0,170);                 // TR area display address
    disp_font(FONT8x16,NORMAL);      //
    disp_str("Rx");                 //
    //rx_meter_scale();               // Draw s-meter scale
}

void display_tx(){
    disp_addr(0,170);                 // TR area display address
    disp_font(FONT8x16,NORMAL);      //
    disp_str("Tx");                 //
    //rx_meter_scale();               // Draw s-meter scale
}
// Start up screens
void display_save(){
    disp_addr(0,60);                 // TR area display address
    disp_font(FONT8x16,NORMAL);      //
    disp_str("SAVE");
    Delay_ms(1000);
    disp_addr(0,60);
    disp_str("    ");
}
void display_a_b(){
    disp_addr(0,60);                 // TR area display address
    disp_font(FONT8x16,NORMAL);      //
    disp_str("A=B");
    Delay_ms(1000);
    disp_addr(0,60);
    disp_str("   ");
   }
void start_up_msg(){
        disp_clr();
        Delay_ms(10);
        disp_addr(5,100);                        // Start up message
        disp_font(FONT8x16,NORMAL);
        disp_str("N5MF");
        disp_addr(7,80);
        disp_str("Si5351a DDS");
        disp_addr(10,80);                        // Version
        //disp_font(FONT8x16,NORMAL);                // Change spacing
        disp_str("Version 1.0");
        disp_font(FONT5x8,NORMAL);              // Restore normal spacing
        Delay_ms(500);
          disp_clr();                                // LCD Initialisation complete
}

// Display operating mode
void display_mode(unsigned int mode){
    disp_addr(0,100);
    disp_font(FONT8x16,NORMAL);

    switch (mode){
        case USB:
        disp_str("USB");
        break;

        case LSB:
        disp_str("LSB");
        break;

        case CW:
        disp_str("CWN");
        break;

        case CWR:
        disp_str("CWR");
        break;
    }
}