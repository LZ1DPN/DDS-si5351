// DSP IF
//
// Display Routines (c) Cumbria Designs
//
//
//#include "ST7735_driver.c"
//#include "meters.h"
#include "display_160x128TFT.h"

char    digit[9];                  // Decimal digits for frequency 0..8
char    blank;                     // Leading zero supression
char    rx_mtr_active;             // S-Meter in use flag
char    tx_mtr_active;             // Tx Meter is use

unsigned int    disp_update;       // Display refresh counter
unsigned int    s_meter_update;    // S-Meter refresh counter
int             agc_dB_offset;     // Offset in dB for display calibration
int             agc_dB_last;       // Previous signal level value

// Flags
int   rit_flag;                    // RIT, 0=OFF, 1=ON
int   fixed_rate;                  // Tuning rate, 0=slow, 1=fast
int   var_rate;                    // Variable rate tuning, 0=off, 1=on
int   tuning_lock;                 // Encoder A lock state 0=unlocked, 1=locked

// Draw the S-Meter scale and bar graph representation of AGC voltage. Increments are
// in 1dB with scale graticule divisions every 6dB up to S9, 10dB up to +20dB and 10dB
// every 5 increments up to +50dB. Total number of increments for FSD are;
// 9*6+20+15=89
//
/*
void rx_meter(){                        // S Meter

    unsigned char i;                    // Loop index
    char dB_diff;                       // Calculate difference between current and last AGC
    char plot_start;                    // Start position for graph update

        if(agc_det>(linear_dB[45])){    // Test for mid point in table
            i=37;                       // Greater than mid point, start from here
        }
        else{
        i=0;                            // Less than mid point, start from zero
        }
        do{
            i++;                        // Increment pointer until it the table entry
        }while(agc_det>(linear_dB[i])); // equals or exceeds agc_det value

     agc_dB=i+codec_gain;               // Add in CODEC gain
     // Look for change and only update that portion of the scale that has changed
     s_meter_update--;                          // Decrement update counter
     if(!s_meter_update){                       // Are we at zero?
         s_meter_update=S_MTR_UPD;              // Yes, reload counter and refresh meter

     disp_addr(BAR,MTR_START);
     for(i=0;i<98;i++){
         if(agc_dB>0){                          // If dB value >0, fill bar
             disp_gra(mtr_fill_bar[i]);
            }
         else{
             disp_gra(mtr_empty_bar[i]);        // If dB value<0, empty bar
         }
         agc_dB--;                              // Decrement dB count
      }
     agc_dB_last=agc_dB;                        // Update historic value
     disp_write();                              // Write display
   }
} 
// Draw scale and empty bar (do this once upon entering Rx)
void rx_meter_scale(){

    unsigned char i;                                // Loop index

    disp_addr(RXSCALE,MTR_START);                   // Point to meter start
    for(i=0;i<98;i++){
        disp_gra(s_mtr_scale[i]);
    }
    disp_write();
    disp_addr(BAR,MTR_START);                       // Point to bar start
    for(i=0;i<98;i++){
        disp_gra(mtr_empty_bar[i]);
    }
    disp_write();
}
*/
// Frequency formatted display

void freq_format(){

      disp_colour(GREEN,BLACK);

      if (digit[7]==0x30){                          // Leading zero supression
         disp_chr(0x20);                            // Blank character position
      }
       else {disp_chr(digit[7]);}                   // Show 10MHz

       disp_chr(digit[6]);                          // Show MHz
       disp_font(FONT12x17NAR,NORMAL);              // Narrow font
       disp_chr(DP12x17);                           // Show Decimal Point
       disp_font(FONT12x17NUM,NORMAL);
       disp_chr(digit[5]);                          // Show 100kHz
       disp_chr(digit[4]);                          // Show 10kHz
       disp_chr(digit[3]);                          // Show kHz
       disp_font(FONT12x17NAR,NORMAL);               // Narrow font
       disp_chr(COMMA12x17);                        // Show comma
       disp_font(FONT12x17NUM,NORMAL);
       disp_chr(digit[2]);                          // show 100s Hz
       disp_chr(digit[1]);                          // Show 10s Hz
       disp_colour(WHITE,BLACK);
 }

void rit_format(){
      if (digit[4]==0x30){                          // Leading zero supression
         disp_chr(0x20);}                           // Blank character position
      else {disp_chr(digit[4]);}                    // No zero, show 10kHz
                                                    // No leading zero supression from here
      disp_chr(digit[3]);                           // Show kHz
      disp_chr(0x2E);                               // Put kHz Decimal Point here
      disp_chr(digit[2]);                           // show 100s Hz
      disp_chr(digit[1]);                           // Show 10s Hz
      disp_str("kHz");                              // Print kHz
 }
// Convert binary value held in "n" into BCD digits for display

void binary_BCD(unsigned long n){                                  //

    unsigned long    decade;                        // Decade value
    unsigned int     i;                             // Declare temporary index

    decade=100000000;                               // Start value (maximum decade, 10^8)
    i=8;                                            // Point digit index to MSD
    do{                                             // Inner decade loop
    digit[i]=0x30;                                  // Initialise decade value at ASCII zero
    while(n>=decade){                               // Calculate decade value
        n=n-decade;                                 // Subtract decade from f
        digit[i]++;                                 // Increment digit decade count
        }
    decade=decade/10;                               // Next lower decade
    i--;                                            // Decrement digit index
    }while (i>0);                                   // Exit when i=0
}

// Converion of an 8 bit value to decimal, resul in digit[2..0]
void binary_BCD_byte(unsigned n){
    unsigned long    decade;                        // Decade value
    int     i;                                      // Declare temporary index

    decade=100 ;                                    // Start value (maximum decade, 10^2)
    i=2;                                            // Point digit index to MSD
    do{                                             // Inner decade loop
    digit[i]=0x30;                                  // Initialise decade value at ASCII zero
    while(n>=decade){                               // Calculate decade value
        n=n-decade;                                 // Subtract decade from f
        digit[i]++;                                 // Increment digit decade count
        }
    decade=decade/10;                               // Next lower decade
    i--;                                            // Decrement digit index
    }while (i>=0);                                  // Exit when i<0
}

void Display_Freq(unsigned long freq){              // Send frequency data to display
    disp_addr(3,8);
    disp_font(FONT12x17NUM,NORMAL);
    binary_BCD(freq);                               // Convert the binary frequency word to BCD
    blank=0;                                        // Clear blanking flag
    freq_format();
}
/*
void display_MHz(){                                 // Add "MHz" to initial display (not updated with frequency)
    disp_font(FONT8x16,NORMAL);                     //
    disp_str("MHz");                                //
}

void display_rate(){                                // Display tuning rate
    disp_font(FONT5x8,NORMAL);  // Set font
    disp_addr(0,118);            // Point to lock  state address
    if(tuning_lock){            // If locked
        disp_str("LOCK ");       // Display LOCK
        }
    else if(var_rate){          // Otherwise if variable rate enabled
        disp_str("VAR  ");       // Show VAR
    }
    else{                       // If we are in fixed rate show tuning rate
        if(fixed_rate){         //
            disp_str("100Hz");   // Show FAST
        }
        else{
            disp_str(" 10Hz");   // Show SLOW
        }
    }
}

void display_agc(){             // Show AGC state
    disp_addr(9,4);             // Point to AGC area
    disp_font(FONT5x8,NORMAL);  // Set up font
    disp_str("AGC");
    disp_addr(10,0);             // Point to AGC area
    switch (agc_mode){
        case AGC_ON_FAST:
        disp_str("FAST");
        break;

        case AGC_ON_SLOW:
        disp_str("SLOW");
        break;

        case AGC_OFF:
        disp_str("OFF ");
        break;
    }
}

void display_rit(signed long rit_freq){ // Show RIT offset
    unsigned long rit_abs;
    disp_addr(7,70);            // Point to RIT area
    disp_font(FONT5x8,NORMAL);  // Set up font
    disp_str("RIT");            // Print RIT
    if(rit_flag){               // If RIT ON
    if(rit_freq>0){             // If positive, prefix with "+"
        disp_str("+");
        }
    else if(rit_freq<0){         // If negative, pefix with "-"
            disp_str("-");
        }
    else if(rit_freq==0){
            disp_str(" ");      // If zero, prefix with a blank
        }
    rit_abs=abs(rit_freq);       // Convert to absolute value
    binary_BCD(rit_abs);         // Convert the binary frequency word to BCD
    rit_format();                // Display RIT value
    }
    else{                        // RIT OFF, clear display area
    disp_str(" OFF     ");       // Clear frequency
    }
}

// Display Setting
//
// Character field 8 chrs wide
void display_setting(unsigned int setting){
    disp_addr(7,2);             // OLED address for function display
    disp_font(FONT5x8,NORMAL);
    disp_colour(RED,BLACK);

    switch (setting){           // Display current function
        case SET_CAL:
            disp_str("VFO CAL ");
            break;

        case SET_RX_BAL:
            disp_str("RX I/Q  ");
            break;

        case SET_TX_BAL:
            disp_str("TX I/Q  ");
            break;

        case SET_MIC_GAIN:
            disp_str("MIC GAIN");
            break;

        case SET_MIC_PRE:
            disp_str("MIC PRE ");
            break;

        case SET_IQ_SWAP:
            disp_str("I/Q SWAP");
            break;
    }
    disp_colour(WHITE,BLACK);
}

// Display submenu associated with current setting
//
void display_submenu(setting){


}

// Display function setting
//
// Character field 8 chrs wide
void display_function(unsigned int function){
    disp_addr(7,2);             // OLED address for function display
    disp_font(FONT5x8,NORMAL);

    switch (function){          // Display current function
        case FUNC_BAND:
            disp_str("BAND    ");
            break;

        case FUNC_MODE:
            disp_str("MODE    ");
            break;

        case FUNC_FILTER:
            disp_str("FILTER  ");
            break;

        case FUNC_AGC:
            disp_str("AGC     ");
            break;
    }
}

// Display operating mode
void display_mode(unsigned int mode){
    disp_addr(0,25);
    disp_font(FONT5x8,NORMAL);

    switch (mode){
        case USB:
        disp_str("USB");
        break;

        case LSB:
        disp_str("LSB");
        break;

        case CW:
        disp_str("CW ");
        break;

        case CWR:
        disp_str("CWR");
        break;
    }
}

// Display VFO Calibration rate
void display_cal(int cal_rate){
    disp_addr(4,2);
    disp_font(FONT5x8,NORMAL);

    if(cal_rate){                               //
        disp_str("Calfast ");                    // Fast tuning rate
    }
        else{
        disp_str("Calfine ");                    // Fine tuning rate
    }
}

// Display gain and phase compensation
void display_comp(int comp_type){
    disp_addr(4,2);
    disp_font(FONT5x8,NORMAL);

    if(!comp_type){                              //
        disp_str("Gain    ");
    }
        else{
        disp_str("Phase   ");
    }
}
// Display I/Q swap states
void display_rx_IQ_swap(int rx_iq_swap){
    disp_addr(4,2);
    disp_font(FONT5x8,NORMAL);

        if(!rx_iq_swap){
            disp_str("Rx Norm ");
        }
        else{
            disp_str("Rx Swap ");
        }
}

void display_tx_IQ_swap(int tx_iq_swap){
    disp_addr(4,2);
    disp_font(FONT5x8,NORMAL);

        if(!tx_iq_swap){
            disp_str("Tx Norm ");
        }
        else{
            disp_str("Tx Swap ");
        }
}
// Display Mic gain in dB, allowing for +20dB fixed gain
void display_mic_gain(signed int mic_dB){

    unsigned int mic_dB_abs;        // Absolute value for display

    disp_addr(4,2);
    disp_font(FONT5x8,NORMAL);

    mic_dB=mic_dB-MIC_FIXED_GAIN;   // Account for fixed CODEC gain

    disp_str("Mic");                // Print "Mic"
    if(mic_dB>0){                   // If positive, prefix with "+"
        disp_str("+");
        }
    else if(mic_dB<0){              // If negative, pefix with "-"
            disp_str("-");
        }
    else if(mic_dB==0){
            disp_str(" ");          // If zero, prefix with a blank
        }
    mic_dB_abs=abs(mic_dB);         // Convert to absolute value
    binary_BCD_byte(mic_dB_abs);    // Convert the binary frequency word to BCD
    // Display Mic gain in dB with leading zero blanking
    if(digit[1]==0x31){             // If digit set to ASCII 1
    disp_chr(digit[1]);             // Print value
    }
    else{                           // If digit 1=0x30
        disp_str(" ");              // Print blank
    }
    disp_chr(digit[0]);             //
    disp_str("dB");                 // Add dB
}

void display_mic_pre(unsigned int mic_pre){

    disp_addr(4,2);
    disp_font(FONT5x8,NORMAL);      //

    binary_BCD_byte(mic_pre);       // Convert the binary frequency word to BCD
    disp_str("Pre   ");             // Print "Pre "
    // Display Mic pre-emph index with leading zero blanking
    if(digit[1]==0x31){             // If set to ASCII 1
        disp_chr(digit[1]);         // Print value
    }
    else{
        disp_str(" ");              // If zero print blank
    }
    disp_chr(digit[0]);             //
}

// Display filter
void display_filter(unsigned int filter){
    disp_addr(0,54);
    disp_font(FONT5x8,NORMAL);
    switch (filter){
        case SSB_1:
        disp_str("2.8kHz");
        break;

        case SSB_2:
        disp_str("2.5kHz");
        break;

        case SSB_3:
        disp_str("2.2kHz");
        break;

        case SSB_4:
        disp_str("2.0kHz");
        break;

        case SSB_5:
        disp_str("1.8kHz");
        break;

        case CW_1:
        disp_str("500Hz ");
        break;

        case CW_2:
        disp_str("350Hz ");
        break;

        case CW_3:
        disp_str("300Hz ");
        break;

        case CW_4:
        disp_str("200Hz ");
        break;
    }
}

// Display Tx/Rx State

void display_tx(){
    disp_addr(0,2);                 // TR area display address
    disp_font(FONT5x8,NORMAL);      //
    disp_str("Tx");                 //
}

void display_rx(){
    disp_addr(0,2);                 // TR area display address
    disp_font(FONT5x8,NORMAL);      //
    disp_str("Rx");                 //
    rx_meter_scale();               // Draw s-meter scale
}
*/
// Start up screens

void start_up_msg(){
        disp_clr();
        delay_ms(500);
        disp_addr(1,16);                        // Start up message
        disp_font(FONT5x8,NORMAL);
        disp_str("SoftRock Backend ");
        disp_addr(3,5);
        disp_str("(c) Cumbria Designs");
        disp_addr(5,16);                        // Version
        disp_font(FONT5x8,WIDE);                // Change spacing
        disp_str("Version 1.0");
        disp_font(FONT5x8,NORMAL);              // Restore normal spacing
        delay_ms(2000);
          disp_clr();                                // LCD Initialisation complete
}