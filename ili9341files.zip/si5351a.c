// 
// Author: Hans Summers, 2015
// Website: http://www.hanssummers.com
//
// A very very simple Si5351a demonstration
// using the Si5351a module kit http://www.hanssummers.com/synth
// Please also refer to SiLabs AN619 which describes all the registers to use
//
//#include <inttypes.h>
//#include "i2cmaster.h"
#include "si5351a.h"

#define I2C_WRITE 0b11000000                // I2C address for writing to the Si5351A
#define I2C_READ  0b11000001                // I2C address for reading to the Si5351A

unsigned int i2cSendRegister(unsigned int reg, unsigned int reg_data)
{
        I2C1_Start();
        I2C1_Wr(I2C_WRITE | 0x00);
        I2C1_Wr(reg);
        I2C1_Wr(reg_data);
        I2C1_Stop();

        return 0;
}

unsigned int i2cReadRegister(unsigned int reg, unsigned int *read_data)
{


        I2C1_Start();
        I2C1_Wr(I2C_READ);
        I2C1_Repeated_Start();
        *read_data = I2C1_Rd(reg);
        I2C1_Stop();

        return 0;
}

//
// Set up specified PLL with mult, num and denom
// mult is 15..90
// num is 0..1,048,575 (0xFFFFF)
// denom is 0..1,048,575 (0xFFFFF)
//
void setupPLL(unsigned int pll, unsigned int mult, unsigned long int num, unsigned long int denom)
{
        unsigned long int P1;                                        // PLL config register P1
        unsigned long int P2;                                        // PLL config register P2
        unsigned long int P3;                                        // PLL config register P3

        P1 = (unsigned long int)(128 * ((float)num / (float)denom));
        P1 = (unsigned long int)(128 * (unsigned long int)(mult) + P1 - 512);
        P2 = (unsigned long int)(128 * ((float)num / (float)denom));
        P2 = (unsigned long int)(128 * num - denom * P2);
        P3 = denom;

        i2cSendRegister(pll + 0, (P3 & 0x0000FF00) >> 8);
        i2cSendRegister(pll + 1, (P3 & 0x000000FF));
        i2cSendRegister(pll + 2, (P1 & 0x00030000) >> 16);
        i2cSendRegister(pll + 3, (P1 & 0x0000FF00) >> 8);
        i2cSendRegister(pll + 4, (P1 & 0x000000FF));
        i2cSendRegister(pll + 5, ((P3 & 0x000F0000) >> 12) | ((P2 & 0x000F0000) >> 16));
        i2cSendRegister(pll + 6, (P2 & 0x0000FF00) >> 8);
        i2cSendRegister(pll + 7, (P2 & 0x000000FF));
}

//
// Set up MultiSynth with integer divider and R divider
// R divider is the bit value which is OR'ed onto the appropriate register, it is a #define in si5351a.h
//
void setupMultisynth(unsigned int synth, unsigned long int divider, unsigned int rDiv)
{
        unsigned long int P1;                                        // Synth config register P1
        unsigned long int P2;                                        // Synth config register P2
        unsigned long int P3;                                        // Synth config register P3

        P1 = 128 * divider - 512;
        P2 = 0;                                                        // P2 = 0, P3 = 1 forces an integer value for the divider
        P3 = 1;

        i2cSendRegister(synth + 0,   (P3 & 0x0000FF00) >> 8);
        i2cSendRegister(synth + 1,   (P3 & 0x000000FF));
        i2cSendRegister(synth + 2,   ((P1 & 0x00030000) >> 16) | rDiv);
        i2cSendRegister(synth + 3,   (P1 & 0x0000FF00) >> 8);
        i2cSendRegister(synth + 4,   (P1 & 0x000000FF));
        i2cSendRegister(synth + 5,   ((P3 & 0x000F0000) >> 12) | ((P2 & 0x000F0000) >> 16));
        i2cSendRegister(synth + 6,   (P2 & 0x0000FF00) >> 8);
        i2cSendRegister(synth + 7,   (P2 & 0x000000FF));
}

//
// Switches off Si5351a output
// Example: si5351aOutputOff(SI_CLK0_CONTROL);
// will switch off output CLK0
//
void si5351aOutputOff(unsigned int clk)
{
        I2C1_Init(100000);
        
        i2cSendRegister(clk, 0x80);                // Refer to SiLabs AN619 to see bit values - 0x80 turns off the output stage

        I2C1_Stop();
}

// 
// Set CLK0 output ON and to the specified frequency
// Frequency is in the range 1MHz to 150MHz
// Example: si5351aSetFrequency(10000000);
// will set output CLK0 to 10MHz
//
// This example sets up PLL A
// and MultiSynth 0 AND 1
// and produces the output on CLK0  AND CLK1
//
void si5351aSetFrequency(unsigned long int frequency, short int quad)
{
        unsigned long int pllFreq;
        unsigned long int xtalFreq = XTAL_FREQ;
        unsigned long int l;
        float f;
        unsigned int mult;
        unsigned long int num;
        unsigned long int denom;
        unsigned long int divider;
        short int set_quad;
        //int offset;
        
        I2C1_Init(100000);                                                // Initialise the I2C
        set_quad = quad;
        divider = 600000000 / frequency;// Calculate the division ratio. 900,000,000 is the maximum internal
                                                                        // PLL frequency: 900MHz
        if (divider % 2) divider--;                // Ensure an even integer division ratio

        pllFreq = divider * frequency;        // Calculate the pllFrequency: the divider * desired output frequency

        mult = pllFreq / xtalFreq;                // Determine the multiplier to get to the required pllFrequency
        l = pllFreq % xtalFreq;                        // It has three parts:
        f = l;                                                        // mult is an integer that must be in the range 15..90
        f *= 1048575;                                        // num and denom are the fractional parts, the numerator and denominator
        f /= xtalFreq;                                        // each is 20 bits (range 0..1048575)
        num = f;                                                // the actual multiplier is  mult + num / denom
        denom = 1048575;                                // For simplicity we set the denominator to the maximum 1048575

        setupPLL(SI_SYNTH_PLL_A, mult, num, denom);                   // Set up PLL A with the calculated multiplication ratio

        setupMultisynth(SI_SYNTH_MS_0, divider, SI_R_DIV_1);            // Set up MultiSynth divider 0, with the calculated divider.
                                                                        // The final R division stage can divide by a power of two, from 1..128. 
                                                                        // reprented by constants SI_R_DIV1 to SI_R_DIV128 (see si5351a.h header file)
                                                                        // If you want to output frequencies below 1MHz, you have to use the 
                                                                        // final R division stage
        setupMultisynth(SI_SYNTH_MS_1, divider, SI_R_DIV_1);
        
        i2cSendRegister(SI_PLL_RESET, 0xA0);                          // Reset the PLL. This causes a glitch in the output. For small changes to
        
        if(set_quad){
        si5351aSetQuad(divider);
        }
        /*                                                             // the parameters, you don't need to reset the PLL, and there is no glitch
        i2cSendRegister(SI_CLK0_PHOFF, 0x00);
        i2cSendRegister(SI_PLL_RESET, 0xA0);
        
        i2cSendRegister(SI_CLK1_PHOFF, 100);
        i2cSendRegister(SI_PLL_RESET, 0xA0);
         */
        i2cSendRegister(SI_CLK0_CONTROL, 0x4F | SI_CLK_SRC_PLL_A);      // Finally switch on the CLK0 output (0x4F)   
        i2cSendRegister(SI_PLL_RESET, 0xA0);                                                                // and set the MultiSynth0 input to be PLL A
        i2cSendRegister(SI_CLK1_CONTROL, 0x4F | SI_CLK_SRC_PLL_A);

        I2C1_Stop();                                                // Exit I2C
}

void si5351aSetQuad(int offset){
        
        i2cSendRegister(SI_CLK0_PHOFF, 0x00);
        i2cSendRegister(SI_PLL_RESET, 0xA0);

        i2cSendRegister(SI_CLK1_PHOFF, offset);   // this adjusts the phase
        i2cSendRegister(SI_PLL_RESET, 0xA0);
        }

void si5351aSet(unsigned long int frequency1)
{
        unsigned long int pllFreq;
        unsigned long int xtalFreq = XTAL_FREQ;
        unsigned long int l;
        float f;
        unsigned int mult;
        unsigned long int num;
        unsigned long int denom;
        unsigned long int divider;

        I2C1_Init(100000);                                                // Initialise the I2C
        
        divider = 900000000 / frequency1;  // Calculate the division ratio. 900,000,000 is the maximum internal
                                                                        // PLL frequency: 900MHz
        if (divider % 2) divider--;                // Ensure an even integer division ratio

        pllFreq = divider * frequency1;        // Calculate the pllFrequency: the divider * desired output frequency

        mult = pllFreq / xtalFreq;                // Determine the multiplier to get to the required pllFrequency
        l = pllFreq % xtalFreq;                        // It has three parts:
        f = l;                                                        // mult is an integer that must be in the range 15..90
        f *= 1048575;                                        // num and denom are the fractional parts, the numerator and denominator
        f /= xtalFreq;                                        // each is 20 bits (range 0..1048575)
        num = f;                                                // the actual multiplier is  mult + num / denom
        denom = 1048575;                                // For simplicity we set the denominator to the maximum 1048575

                                                                        // Set up PLL A with the calculated multiplication ratio
        setupPLL(SI_SYNTH_PLL_B, mult, num, denom);
        //setupPLL(SI_SYNTH_PLL_B, mult, num, denom);                                                               // Set up MultiSynth divider 0, with the calculated divider.
                                                                        // The final R division stage can divide by a power of two, from 1..128.
                                                                        // reprented by constants SI_R_DIV1 to SI_R_DIV128 (see si5351a.h header file)
                                                                        // If you want to output frequencies below 1MHz, you have to use the
                                                                        // final R division stage
        setupMultisynth(SI_SYNTH_MS_2, divider, SI_R_DIV_1);
        //setupMultisynth(SI_SYNTH_MS_1, divider, SI_R_DIV_1);                                                                // Reset the PLL. This causes a glitch in the output. For small changes to
                                                                        // the parameters, you don't need to reset the PLL, and there is no glitch
        //i2cSendRegister(SI_PLL_RESET, 0xA0);

        //setupMultisynth(SI_SYNTH_MS_1, divider, SI_R_DIV_1);

        i2cSendRegister(SI_PLL_RESET, 0xA0);
                                                                        // Finally switch on the CLK0 output (0x4F)
        i2cSendRegister(SI_CLK2_CONTROL, 0x4F | SI_CLK_SRC_PLL_B);                                                                // and set the MultiSynth0 input to be PLL A
        //i2cSendRegister(SI_CLK1_CONTROL, 0x4F | SI_CLK_SRC_PLL_A);

        I2C1_Stop();                                                // Exit I2C
}